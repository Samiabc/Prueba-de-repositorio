from view.frm_menu import FrmMenu

if __name__ == "__main__":
    app = FrmMenu()
    app.run()