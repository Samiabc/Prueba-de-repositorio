import { MongoClient } from "mongodb";

const uri = "mongodb+srv://Arelis:Arelis2006@cluster0.qdn4zsf.mongodb.net/?retryWrites=true&w=majority";

const client = new MongoClient(uri);
let collection;

export async function getCollection() {
    if (!collection) {
        await client.connect();
        const db = client.db("BookSalesDB");
        collection = db.collection("BookSales");
    }
    return collection;
}