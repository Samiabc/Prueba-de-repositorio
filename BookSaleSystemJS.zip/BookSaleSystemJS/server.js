import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { BookController } from "./controller/bookController.js";
import { SaleController } from "./controller/saleController.js";

const app = express();
const PORT = 3000;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(express.json());
app.use(express.static(path.join(__dirname, "view")));

const bookController = new BookController();
const saleController = new SaleController();

app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "view", "menu.html"));
});

app.get("/book-sale", (req, res) => {
    res.sendFile(path.join(__dirname, "view", "bookSale.html"));
});

app.get("/sales-report", (req, res) => {
    res.sendFile(path.join(__dirname, "view", "salesReport.html"));
});

app.get("/books", (req, res) => {
    res.json(bookController.getAllBooks());
});

app.get("/sales", async (req, res) => {
    const sales = await saleController.getAllSales();
    res.json(sales);
});

app.post("/sales", async (req, res) => {
    await saleController.saveSale(req.body);
    res.sendStatus(201);
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});