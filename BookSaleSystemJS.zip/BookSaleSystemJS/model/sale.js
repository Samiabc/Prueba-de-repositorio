export class Sale {
    constructor(bookTitle, unitPrice, quantity) {
        this.bookTitle = bookTitle;
        this.unitPrice = unitPrice;
        this.quantity = quantity;
        this.calculateTotals();
        this.date = new Date();
    }

    calculateTotals() {
        this.subtotal = this.unitPrice * this.quantity;
        this.total = this.subtotal;
    }
}