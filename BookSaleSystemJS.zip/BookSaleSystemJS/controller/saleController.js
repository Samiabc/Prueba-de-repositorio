import { Sale } from "../model/sale.js";
import { getCollection } from "../utils/mongodbConnection.js";

export class SaleController {

    async saveSale(data) {
        const collection = await getCollection();

        const sale = new Sale(
            data.bookTitle,
            Number(data.unitPrice),
            Number(data.quantity)
        );

        await collection.insertOne({
            bookTitle: sale.bookTitle,
            unitPrice: sale.unitPrice,
            quantity: sale.quantity,
            total: sale.total,
            date: sale.date
        });
    }

    async getAllSales() {
        const collection = await getCollection();
        return await collection.find().toArray();
    }
}