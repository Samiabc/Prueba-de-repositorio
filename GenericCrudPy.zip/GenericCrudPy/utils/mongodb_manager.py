from pymongo import MongoClient
from utils.config import MONGO_URI, DATABASE_NAME, COLLECTION_NAME
from model.generic_entity import GenericEntity

class MongoDBManager:
    def __init__(self):
        self.client = MongoClient(MONGO_URI)
        self.db = self.client[DATABASE_NAME]
        self.collection = self.db[COLLECTION_NAME]

    def find_all(self):
        entities = []
        for doc in self.collection.find():
            entities.append(GenericEntity(doc["id"], doc["attributes"]))
        return entities

    def find_by_id(self, entity_id):
        doc = self.collection.find_one({"id": entity_id})
        if doc:
            return GenericEntity(doc["id"], doc["attributes"])
        return None

    def insert(self, entity):
        self.collection.insert_one({
            "id": entity.id,
            "attributes": entity.attributes
        })
        return True

    def update(self, entity_id, entity):
        result = self.collection.update_one(
            {"id": entity_id},
            {"$set": {"attributes": entity.attributes}}
        )
        return result.modified_count > 0

    def delete(self, entity_id):
        result = self.collection.delete_one({"id": entity_id})
        return result.deleted_count > 0