MONGO_URI = "mongodb://localhost:27017"
DATABASE_NAME = "genericdb"
COLLECTION_NAME = "entities"