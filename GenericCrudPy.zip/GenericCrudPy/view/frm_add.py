import tkinter as tk
from tkinter import messagebox
from model.generic_entity import GenericEntity

class FrmAdd(tk.Toplevel):
    def __init__(self, controller):
        super().__init__()
        self.controller = controller
        self.title("Add Entity")
        self.geometry("300x200")

        tk.Label(self, text="ID (numbers only):").pack()
        self.entry_id = tk.Entry(self)
        self.entry_id.pack()

        tk.Label(self, text="Attributes:").pack()
        self.entry_attributes = tk.Entry(self)
        self.entry_attributes.pack()

        tk.Button(self, text="Save", command=self.save).pack(pady=10)

    def save(self):
        entity_id = self.entry_id.get().strip()
        attributes = self.entry_attributes.get().strip()

        if not entity_id.isdigit():
            messagebox.showerror("Error", "ID must be numeric")
            return

        if attributes == "":
            messagebox.showerror("Error", "Attributes cannot be empty")
            return

        if self.controller.get_by_id(entity_id):
            messagebox.showerror("Error", "ID already exists")
            return

        entity = GenericEntity(entity_id, attributes)
        self.controller.create(entity)

        messagebox.showinfo("Success", "Entity added successfully")
        self.destroy()