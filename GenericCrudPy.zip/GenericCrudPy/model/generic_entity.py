class GenericEntity:
    def __init__(self, entity_id, attributes):
        self.id = entity_id
        self.attributes = attributes