package ec.edu.espe.genericcrud.controller;

import ec.edu.espe.genericcrud.model.GenericEntity;
import ec.edu.espe.genericcrud.utils.MongoDBManager;
import java.util.List;
/**
 *
 * @author Arelis Samantha Bonilla Cruz, Student, @ESPE
 */
public class GenericController {

    private MongoDBManager mongo;
    
    public String getNextId() {
        return mongo.getNextId();
    }
    public GenericController() {
        mongo = new MongoDBManager();
    }

    public List<GenericEntity> getAll() {
        return mongo.findAll();
    }

    public GenericEntity getById(String id) {
        return mongo.findById(id);
    }

    public boolean create(GenericEntity entity) {
        return mongo.insert(entity);
    }

    public boolean update(String id, GenericEntity entity) {
        return mongo.update(id, entity);
    }

    public boolean delete(String id) {
        return mongo.delete(id);
    }
}