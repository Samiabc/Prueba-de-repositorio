package ec.edu.espe.genericcrud.utils;

/**
 *
 * @author Arelis Samantha Bonilla Cruz, Student, @ESPE
 */
public class Config {
    public static final String CONNECTION_STRING = "mongodb://localhost:27017";
    public static final String DATABASE_NAME = "GenericDB";
    public static final String COLLECTION_NAME = "genericCollection";

    public static final String ID_FIELD = "id";
}
