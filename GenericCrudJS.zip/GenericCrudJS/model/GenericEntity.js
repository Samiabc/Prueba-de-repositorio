export class GenericEntity {
    constructor(attributes = {}) {
        this.attributes = attributes;
    }
}