import { MongoClient, ObjectId } from "mongodb";
import { Config } from "./Config.js";

export class MongoDBManager {
    constructor() {
        this.client = new MongoClient(Config.mongoUri);
        this.db = null;
        this.collection = null;
    }

    async connect() {
        if (!this.db) {
            await this.client.connect();
            this.db = this.client.db(Config.dbName);
            this.collection = this.db.collection(Config.collectionName);
        }
    }

    async findAll() {
        await this.connect();
        return await this.collection.find({}).toArray();
    }

    async findById(id) {
        await this.connect();
        return await this.collection.findOne({ _id: new ObjectId(id) });
    }

    async insert(entity) {
        await this.connect();
        return await this.collection.insertOne(entity);
    }

    async update(id, entity) {
        await this.connect();
        return await this.collection.updateOne(
            { _id: new ObjectId(id) },
            { $set: entity }
        );
    }

    async delete(id) {
        await this.connect();
        return await this.collection.deleteOne({ _id: new ObjectId(id) });
    }
}