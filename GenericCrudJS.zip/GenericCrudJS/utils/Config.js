export const Config = {
    mongoUri: "mongodb://localhost:27017",
    dbName: "genericcrud",
    collectionName: "entities",
    port: 3000
};